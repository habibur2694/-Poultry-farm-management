<!DOCTYPE html>
<html>
<head>
    <title>Historical Price Trends</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body style="font-family: Arial, sans-serif; background: #f0f5f5; padding: 30px;">
    <h2>📈 Historical Price Trends</h2>
    <canvas id="priceChart" width="1000" height="400" style="background:white; border-radius:10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);"></canvas>

<?php
$conn = new mysqli("localhost", "root", "", "farm");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$products = ['Broiler Chicken', 'Eggs', 'Poultry Feed'];
$labels = [];
$data_sets = [];

foreach ($products as $product) {
    $sql = "SELECT record_date, price FROM price_history WHERE product_name = '$product' ORDER BY record_date ASC";
    $result = $conn->query($sql);
    
    $dates = [];
    $prices = [];

    while ($row = $result->fetch_assoc()) {
        $dates[] = $row['record_date'];
        $prices[] = $row['price'];
    }

    if (empty($labels)) $labels = $dates;

    $data_sets[] = [
        "label" => $product,
        "data" => $prices,
        "fill" => true,
        "tension" => 0.4,
        "borderWidth" => 2
    ];
}
$conn->close();
?>

<script>
const ctx = document.getElementById('priceChart').getContext('2d');

const chart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [
            {
                label: <?= json_encode($data_sets[0]['label']) ?>,
                data: <?= json_encode($data_sets[0]['data']) ?>,
                borderColor: '#00796b',
                backgroundColor: 'rgba(0,121,107,0.1)',
                tension: 0.4,
                fill: true,
                borderWidth: 2
            },
            {
                label: <?= json_encode($data_sets[1]['label']) ?>,
                data: <?= json_encode($data_sets[1]['data']) ?>,
                borderColor: '#ff9800',
                backgroundColor: 'rgba(255,152,0,0.1)',
                tension: 0.4,
                fill: true,
                borderWidth: 2
            },
            {
                label: <?= json_encode($data_sets[2]['label']) ?>,
                data: <?= json_encode($data_sets[2]['data']) ?>,
                borderColor: '#3f51b5',
                backgroundColor: 'rgba(63,81,181,0.1)',
                tension: 0.4,
                fill: true,
                borderWidth: 2
            }
        ]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { position: 'top' }
        },
        scales: {
            y: {
                beginAtZero: false,
                title: { display: true, text: 'Price (Tk)' }
            },
            x: {
                title: { display: true, text: 'Date' }
            }
        }
    }
});
</script>

</body>
</html>