<?php
require 'connection.php';

$days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
$present = array_fill(0, 7, 0);
$absent = array_fill(0, 7, 0);

$sql = "SELECT attendance_date, status FROM attendance";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    $day = date('w', strtotime($row['attendance_date'])); // 0 = Sun ... 6 = Sat
    if ($row['status'] === 'Present') {
        $present[$day]++;
    } elseif ($row['status'] === 'Absent') {
        $absent[$day]++;
    }
}

$conn->close();

echo json_encode([
    "labels" => $days,
    "present" => $present,
    "absent" => $absent
]);