<?php
require 'connection.php';
$today = date('Y-m-d');

$sql = "
SELECT 
    w.name,
    r.role_name,
    w.hour_per_day,
    w.task,
    w.performance,
    w.payroll,
    a.status AS attendance_status
FROM 
    workers w
JOIN 
    roles r ON w.role_id = r.role_id
LEFT JOIN 
    attendance a ON a.worker_id = w.worker_id AND a.attendance_date = ?
ORDER BY w.name
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $today);
$stmt->execute();
$result = $stmt->get_result();
?>