<?php
require_once 'connection.php';

$sql = "SELECT * FROM market_prices ORDER BY market_location, product_name";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $change_24h = $row['change_24h'];
        $change_7d = $row['change_7d'];

        function format_change($value) {
            if ($value > 0) return '<span class="price-change-up">+'. $value .'% <i class="fas fa-arrow-up"></i></span>';
            if ($value < 0) return '<span class="price-change-down">'. $value .'% <i class="fas fa-arrow-down"></i></span>';
            return '<span class="price-change-neutral">0.0%</span>';
        }

        echo "<tr>
            <td>{$row['product_name']}</td>
            <td>{$row['market_location']}</td>
            <td>\${$row['current_price']}</td>
            <td>" . format_change($change_24h) . "</td>
            <td>" . format_change($change_7d) . "</td>
            <td>\${$row['regional_avg']}</td>
            <td><button class='btn btn-sm btn-outline-primary'>Set Alert</button></td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='7' class='text-center'>No market data found.</td></tr>";
}

$conn->close();
?>