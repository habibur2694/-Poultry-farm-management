<?php
require_once 'connection.php';

// Broiler Chicken
$broiler = $conn->query("SELECT current_price, change_7d FROM market_prices WHERE product_name = 'Broiler Chicken' ORDER BY updated_at DESC LIMIT 1")->fetch_assoc();

// Eggs
$egg = $conn->query("SELECT current_price, change_7d FROM market_prices WHERE product_name = 'Eggs' ORDER BY updated_at DESC LIMIT 1")->fetch_assoc();

// Alerts
$alerts_total = $conn->query("SELECT COUNT(*) AS total FROM price_alerts")->fetch_assoc()['total'];
$alerts_today = $conn->query("SELECT COUNT(*) AS today FROM price_alerts WHERE DATE(created_at) = CURDATE()")->fetch_assoc()['today'];

// Variance
$prices = $conn->query("SELECT MAX(current_price) AS max_price, MIN(current_price) AS min_price FROM market_prices WHERE product_name = 'Broiler Chicken'");
$range = $prices->fetch_assoc();
$variance = (($range['max_price'] - $range['min_price']) / ($range['min_price'] ?: 1)) * 100;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Market Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #e9f7f1;
            padding: 30px;
        }

        .row {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .stat-card {
            background: #fff;
            border-radius: 14px;
            padding: 20px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.05);
            flex: 1 1 220px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .stat-num {
            font-size: 1.8rem;
            font-weight: bold;
        }

        .stat-title {
            color: #666;
            margin: 5px 0;
        }

        .text-success {
            color: #27ae60;
        }

        .text-danger {
            color: #e74c3c;
        }

        .stat-icon {
            background: #003a2d;
            color: white;
            padding: 12px;
            border-radius: 12px;
            font-size: 18px;
        }
    </style>
</head>
<body>

<h2>Market Price Monitoring</h2>
<div class="row">
    <!-- Broiler -->
    <div class="stat-card">
        <div>
            <div class="stat-num">$<?= number_format($broiler['current_price'], 2) ?></div>
            <div class="stat-title">Current Broiler Price/kg</div>
            <small class="<?= $broiler['change_7d'] >= 0 ? 'text-success' : 'text-danger' ?>">
                <?= $broiler['change_7d'] >= 0 ? '↑' : '↓' ?>
                <?= abs($broiler['change_7d']) ?>% from last week
            </small>
        </div>
        <div class="stat-icon"><i class="fas fa-weight"></i></div>
    </div>

    <!-- Eggs -->
    <div class="stat-card">
        <div>
            <div class="stat-num">$<?= number_format($egg['current_price'], 2) ?></div>
            <div class="stat-title">Current Egg Price/dozen</div>
            <small class="<?= $egg['change_7d'] >= 0 ? 'text-success' : 'text-danger' ?>">
                <?= $egg['change_7d'] >= 0 ? '↑' : '↓' ?>
                <?= abs($egg['change_7d']) ?>% from last week
            </small>
        </div>
        <div class="stat-icon"><i class="fas fa-egg"></i></div>
    </div>

    <!-- Alerts -->
    <div class="stat-card">
        <div>
            <div class="stat-num"><?= $alerts_total ?></div>
            <div class="stat-title">Active Price Alerts</div>
            <small class="text-success">↑ <?= $alerts_today ?> new today</small>
        </div>
        <div class="stat-icon"><i class="fas fa-bell"></i></div>
    </div>

    <!-- Variance -->
    <div class="stat-card">
        <div>
            <div class="stat-num"><?= number_format($variance, 1) ?>%</div>
            <div class="stat-title">Regional Price Variance</div>
            <small class="text-success">↑ <?= number_format($variance * 0.15, 1) ?>% from last month</small>
        </div>
        <div class="stat-icon"><i class="fas fa-map-marked-alt"></i></div>
    </div>
</div>
<br><br>
<?php
require_once 'connection.php';

$market_prices = $conn->query("SELECT * FROM market_prices ORDER BY product_name");

function getRegionalAvg($conn, $product, $unit) {
    $result = $conn->query("SELECT AVG(current_price) AS avg_price FROM market_prices WHERE product_name = '$product' AND unit = '$unit'");
    return $result->fetch_assoc()['avg_price'] ?? 0;
}
?>

<head>
    <meta charset="UTF-8">
    <title>Market Price Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            background: #f1faf3;
            font-family: 'Segoe UI', sans-serif;
            padding: 30px;
        }
        .container {
            display: flex;
            gap: 20px;
        }
        .tabs {
            background: white;
            border-radius: 12px;
            flex: 3;
            padding: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }
        .tabs ul {
            list-style: none;
            display: flex;
            border-bottom: 2px solid #ccc;
            padding-left: 0;
        }
        .tabs ul li {
            margin-right: 30px;
            padding: 10px;
            font-weight: bold;
            color: #333;
            cursor: pointer;
            border-bottom: 3px solid transparent;
        }
        .tabs ul li.active {
            color: #064e3b;
            border-bottom: 3px solid #064e3b;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        table thead {
            background: #f7fdfb;
        }
        table th, table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }
        .text-success {
            color: #27ae60;
        }
        .text-danger {
            color: #e74c3c;
        }
        .btn-alert {
            padding: 6px 10px;
            border: 1px solid #007bff;
            border-radius: 5px;
            color: #007bff;
            background: #fff;
            cursor: pointer;
            font-size: 13px;
        }
        .recommendations {
            flex: 1;
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }
        .recommendations h3 {
            margin-top: 0;
            margin-bottom: 20px;
        }
        .recommendation-card {
            border-left: 4px solid #199a6d;
            background: #f9fefb;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 15px;
        }
        .recommendation-card i {
            margin-right: 10px;
            color: #199a6d;
        }
    </style>

<div class="container">
    <div class="tabs">
        <ul>
            <li class="active">Current Prices</li>
           
           <li>
  <a href="Historical_chart.php" 
     style="display: block; 
            padding: 12px 20px; 
            text-decoration: none; 
            color: #ffffff; 
            font-weight: 500; 
            background-color: #2d5f4e; 
            border-radius: 6px; 
            transition: background 0.3s, color 0.3s;"
     onmouseover="this.style.backgroundColor='#45a079'" 
     onmouseout="this.style.backgroundColor='#2d5f4e'">
     Historical Trends
  </a>
</li>
           <li>
  <a href="regional_price_chart.php" 
     style="display: block; 
            padding: 12px 20px; 
            text-decoration: none; 
            color: #ffffff; 
            font-weight: 500; 
            background-color: #2d5f4e; 
            border-radius: 6px; 
            transition: background 0.3s, color 0.3s;"
     onmouseover="this.style.backgroundColor='#45a079'" 
     onmouseout="this.style.backgroundColor='#2d5f4e'">
     Regional Price Comparison
  </a>
</li>         
        </ul>

        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Market</th>
                    <th>Current Price</th>
                    <th>24h Change</th>
                    <th>7d Change</th>
                    <th>Regional Avg</th>
                    
                </tr>
            </thead>
            <tbody>
            <?php while ($row = $market_prices->fetch_assoc()): 
                $regionalAvg = getRegionalAvg($conn, $row['product_name'], $row['unit']);
                $arrow24 = $row['change_24h'] > 0 ? '↑' : ($row['change_24h'] < 0 ? '↓' : '');
                $arrow7d = $row['change_7d'] > 0 ? '↑' : ($row['change_7d'] < 0 ? '↓' : '');
                $class24 = $row['change_24h'] > 0 ? 'text-success' : ($row['change_24h'] < 0 ? 'text-danger' : '');
                $class7d = $row['change_7d'] > 0 ? 'text-success' : ($row['change_7d'] < 0 ? 'text-danger' : '');
                ?>
                <tr>
                    <td><?= $row['product_name'] ?></td>
                    <td><?= $row['market_location'] ?></td>
                    <td>$<?= number_format($row['current_price'], 2) . $row['unit'] ?></td>
                    <td class="<?= $class24 ?>"><?= $row['change_24h'] ?>% <?= $arrow24 ?></td>
                    <td class="<?= $class7d ?>"><?= $row['change_7d'] ?>% <?= $arrow7d ?></td>
                    <td>$<?= number_format($regionalAvg, 2) . $row['unit'] ?></td>
                    
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>

<?php
require_once 'connection.php';

// Upcoming week: next Monday to Sunday
$nextMonday = date('M j', strtotime('next monday'));
$nextSunday = date('M j', strtotime('next sunday'));
$dateRange = "$nextMonday – $nextSunday";

// Get Broiler price in Dhaka Central
$dhakaPrice = $conn->query("SELECT current_price FROM market_prices 
                            WHERE product_name = 'Broiler Chicken' 
                            AND market_location = 'Dhaka Central' 
                            ORDER BY updated_at DESC LIMIT 1")->fetch_assoc()['current_price'] ?? 0;

// Get regional average for Broiler
$regionalAvg = $conn->query("SELECT AVG(current_price) AS avg_price FROM market_prices 
                             WHERE product_name = 'Broiler Chicken'")->fetch_assoc()['avg_price'] ?? 1;

$priceDiff = $dhakaPrice - $regionalAvg;
$percentDiff = $regionalAvg ? ($priceDiff / $regionalAvg * 100) : 0;
?>
<div class="recommendations">
    <h3>Pricing Strategy Recommendations</h3>

    <div class="recommendation-card">
        <p><i class="fas fa-lightbulb"></i><strong>Best Selling Window</strong><br>
            Next week (<?= $dateRange ?>) projected 8–12% price increase for broilers in Dhaka region.
        </p>
    </div>

    <div class="recommendation-card">
        <p><i class="fas fa-map-marker-alt"></i><strong>Optimal Market Location</strong><br>
            Dhaka Central market currently offers <?= number_format($percentDiff, 1) ?>% 
            <?= $priceDiff > 0 ? 'higher' : 'lower' ?> prices than regional average.
        </p>
    </div>

    <div class="recommendation-card">
        <p><i class="fas fa-boxes"></i><strong>Inventory Suggestion</strong><br>
            Hold 15% more eggs for next 2 weeks, expected price recovery.
        </p>
    </div>
</div>
            </div>
            <br><br>
            
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f0f5f5;
      margin: 0;
      padding: 40px;
    }

    .container {
      display: flex;
      justify-content: space-between;
      gap: 20px;
      flex-wrap: wrap;
    }

    .notice-board, .gov-board {
      flex: 1;
      min-width: 300px;
      background-color: #ffffff;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .notice-board h2,
    .gov-board h2 {
      text-align: center;
      font-size: 22px;
      margin-bottom: 20px;
      color: #004d40;
    }

    .notice {
      padding: 15px;
      border-left: 6px solid #00796b;
      margin-bottom: 15px;
      background-color: #e0f2f1;
      border-radius: 5px;
    }

    .notice-title {
      font-size: 16px;
      font-weight: bold;
      color: #004d40;
    }

    .notice-date {
      float: right;
      font-size: 12px;
      color: #666;
    }

    .notice-description {
      margin-top: 8px;
      font-size: 14px;
      color: #333;
    }

    .tag {
      display: inline-block;
      background: #00695c;
      color: white;
      padding: 3px 8px;
      font-size: 12px;
      border-radius: 4px;
      margin-top: 6px;
    }

    .gov-links li {
      list-style: none;
      margin-bottom: 15px;
    }

    .gov-links a {
      display: block;
      padding: 12px 20px;
      text-decoration: none;
      color: #ffffff;
      font-weight: 500;
      background-color: #2d5f4e;
      border-radius: 6px;
      transition: background 0.3s;
    }

    .gov-links a:hover {
      background-color: #45a079;
    }

    @media screen and (max-width: 768px) {
      .container {
        flex-direction: column;
      }
    }
  </style>


  <div class="container">

    <!-- Left: Notice Board -->
    <div class="notice-board">
      <h2>📌 Notice Board</h2>

      <div class="notice">
        <div class="notice-title">Market closed on Friday <span class="notice-date">22 June 2025</span></div>
        <div class="notice-description">
          Due to maintenance, all local markets will remain closed this Friday.
        </div>
        <div class="tag">Announcement</div>
      </div>

      <div class="notice">
        <div class="notice-title">Price update delayed <span class="notice-date">21 June 2025</span></div>
        <div class="notice-description">
          Server downtime caused a delay in updating broiler and egg prices today.
        </div>
        <div class="tag">System</div>
      </div>

      <div class="notice">
        <div class="notice-title">Import permit deadline <span class="notice-date">20 June 2025</span></div>
        <div class="notice-description">
          Submit poultry import requests by June 30 to avoid delays.
        </div>
        <div class="tag">Regulation</div>
      </div>
    </div>

    <!-- Right: Important Websites -->
    <div class="gov-board">
      <h2>🌐 All Important Websites</h2>
      <ul class="gov-links">
        <li><a href="https://dls.gov.bd/">DLS (Department of Livestock Services)</a></li>
        <li><a href="https://mofl.gov.bd/">Ministry of Fisheries and Livestock</a></li>
        <li><a href="https://bbs.gov.bd/">BBS (Bangladesh Bureau of Statistics)</a></li>
      </ul>
    </div>

  </div>
  <br>
<footer style="
    background-color: #00130d;
    color: white;
    text-align: center;
    padding: 10px 0;
    font-family: 'Segoe UI', sans-serif;
    font-size: 14px;
    border-top: 2px solid #d9e3dc;">
    © 2025 Smart Poultry Farm. All rights reserved.
</footer>

</body>
</html>