<?php
// chart.php

require 'connection.php';

// Get attendance status counts
$status_counts = ['Present' => 0, 'Late' => 0, 'Absent' => 0];
$count_sql = "SELECT status, COUNT(*) as total FROM attendance GROUP BY status";
$count_result = $conn->query($count_sql);
while ($row = $count_result->fetch_assoc()) {
    $status_counts[$row['status']] = $row['total'];
}
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Attendance Chart</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 30px;
            background: #f4f4f4;
            text-align: center;
        }
        .chart-container {
            width: 500px;
            margin: auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
            border-radius: 10px;
        }
        h2 {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="chart-container">
    <h2>Attendance Summary</h2>
    <canvas id="attendanceChart" width="400" height="300"></canvas>
</div>

<script>
const ctx = document.getElementById('attendanceChart').getContext('2d');
const attendanceChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Present', 'Late', 'Absent'],
        datasets: [{
            label: 'Number of Workers',
            data: [
                <?= $status_counts['Present'] ?>,
                <?= $status_counts['Late'] ?>,
                <?= $status_counts['Absent'] ?>
            ],
            backgroundColor: ['green', 'orange', 'red'],
            borderWidth: 1
        }]
    },
    options: {
        plugins: {
            legend: { display: false }
        },
        scales: {
            y: {
                beginAtZero: true,
                stepSize: 1,
                title: {
                    display: true,
                    text: 'Count'
                }
            }
        }
    }
});
</script>

</body>
</html>