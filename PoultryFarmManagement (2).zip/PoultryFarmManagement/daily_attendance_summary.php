<?php
require 'connection.php';

// Prepare query to count status by date
$sql = "SELECT attendance_date, status, COUNT(*) as count
        FROM attendance
        GROUP BY attendance_date, status
        ORDER BY attendance_date ASC";

$result = $conn->query($sql);

// Structure data
$data = [];
while ($row = $result->fetch_assoc()) {
    $date = $row['attendance_date'];
    $status = $row['status'];
    $count = $row['count'];

    if (!isset($data[$date])) {
        $data[$date] = ['Present' => 0, 'Late' => 0, 'Absent' => 0];
    }
    $data[$date][$status] = $count;
}

$labels = array_keys($data);
$presentData = array_column($data, 'Present');
$lateData = array_column($data, 'Late');
$absentData = array_column($data, 'Absent');

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daily Attendance Summary</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
    
            padding: 30px;
            background: #f5f6fa;
            text-align: center;
        }
        .chart-container {
            max-width: 1700px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 0 12px rgba(0,0,0,0.1);
        }
        canvas {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<h2>Daily Attendance Chart (Present / Absent / Late)</h2>

<div class="chart-container">
    <canvas id="attendanceChart" height="110"></canvas>
</div>

<script>
const ctx = document.getElementById('attendanceChart').getContext('2d');
const chart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [
            {
                label: 'Present',
                data: <?= json_encode($presentData) ?>,
                backgroundColor: 'green'
            },
            {
                label: 'Absent',
                data: <?= json_encode($absentData) ?>,
                backgroundColor: 'red'
            },
            {
                label: 'Late',
                data: <?= json_encode($lateData) ?>,
                backgroundColor: 'orange'
            }
        ]
    },
    options: {
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: 'Attendance Status by Date'
            },
            legend: {
                position: 'top'
            }
        },
        scales: {
            x: {
                stacked: false
            },
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Number of Workers'
                }
            }
        }
    }
});
</script>

</body>
</html>