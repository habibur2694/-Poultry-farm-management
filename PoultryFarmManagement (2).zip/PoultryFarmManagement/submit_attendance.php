<?php
require 'connection.php';

$date = $_POST['date'];
$labor_id = $_POST['labor_id'];
$name = $_POST['name'];
$role_name = $_POST['role'];
$status = $_POST['status'];

// Get or insert role
$role_stmt = $conn->prepare("SELECT role_id FROM roles WHERE role_name = ?");
$role_stmt->bind_param("s", $role_name);
$role_stmt->execute();
$role_result = $role_stmt->get_result();

if ($role_result->num_rows > 0) {
    $role_id = $role_result->fetch_assoc()['role_id'];
} else {
    $insert_role = $conn->prepare("INSERT INTO roles (role_name) VALUES (?)");
    $insert_role->bind_param("s", $role_name);
    $insert_role->execute();
    $role_id = $insert_role->insert_id;
}

// Get or insert worker
if (!empty($labor_id)) {
    $worker_check = $conn->prepare("SELECT worker_id FROM workers WHERE labor_id = ?");
    $worker_check->bind_param("s", $labor_id);
} else {
    $worker_check = $conn->prepare("SELECT worker_id FROM workers WHERE name = ? AND role_id = ?");
    $worker_check->bind_param("si", $name, $role_id);
}

$worker_check->execute();
$worker_result = $worker_check->get_result();

if ($worker_result->num_rows > 0) {
    $worker_id = $worker_result->fetch_assoc()['worker_id'];
} else {
    $insert_worker = $conn->prepare("INSERT INTO workers (labor_id, name, role_id) VALUES (?, ?, ?)");
    $insert_worker->bind_param("ssi", $labor_id, $name, $role_id);
    $insert_worker->execute();
    $worker_id = $insert_worker->insert_id;
}

// Insert or update attendance
$attendance_stmt = $conn->prepare("INSERT INTO attendance (worker_id, attendance_date, status)
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE status = VALUES(status)");
$attendance_stmt->bind_param("iss", $worker_id, $date, $status);

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Submission Result</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php
if ($attendance_stmt->execute()) {
    echo "<h2>✅ Attendance Submitted</h2>";
    echo "<table>
            <tr><th>Date</th><td>$date</td></tr>
            <tr><th>Name</th><td>$name</td></tr>
            <tr><th>Labor ID</th><td>" . ($labor_id ?: 'N/A') . "</td></tr>
            <tr><th>Role</th><td>$role_name</td></tr>
            <tr><th>Status</th><td>$status</td></tr>
          </table>";
    echo "<br><div style='text-align:center; margin-top: 20px;'>
        <a href='labour.php' 
           style='display: inline-block; 
                  background-color:#00796b; 
                  color: white; 
                  padding: 10px 20px; 
                  text-decoration: none; 
                  font-weight: bold; 
                  border-radius: 5px; 
                  transition: background 0.3s;'
           onmouseover=\"this.style.backgroundColor='#37474f'\"
           onmouseout=\"this.style.backgroundColor='#546e7a'\">
            ◀ Back to Attendance Form
        </a>
      </div>";
} else {
    echo "<h3>Error: " . $attendance_stmt->error . "</h3>";
}
$conn->close();
?>
</body>
</html>