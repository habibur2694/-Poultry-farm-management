<body>
    <title>Labour Management</title>
    <h1>Feather Flow - Labour Management</h1>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="style.css">
    <div class="container">
        <div class="card">
            <h3>Total Workforce</h3>
            <p>120 Workers (80 Permanent, 60 Contract, 20 Probation)</p>
        </div>
        <div class="card">
            <h3>Total Time Worked</h3>
            <p>24hr 32min this week</p>
        </div>
        <div class="card attendance-card">
            <h3>Attendance Input</h3>
            <form action="submit_attendance.php" method="POST">
                <label>Date</label>
                <input type="date" name="date" required>

                <label>Labor ID </label>
                <input type="text" name="labor_id">

                <label>Name</label>
                <input type="text" name="name" required>

                <label>Role</label>
                <select name="role" required>
                    <option>Field Worker</option>
                    <option>Feeder</option>
                    <option>Cleaner</option>
                    <option>Irrigation</option>
                </select>

                <label>Attendance Status</label>
                <select name="status" required>
                    <option>Present</option>
                    <option>Late</option>
                    <option>Absent</option>
                </select>

                <button type="submit">Submit Attendance</button>
            </form>
        </div>
        <div class="card">
            <h3>Performance</h3>
            <?php
require 'connection.php';

// Query for highest present
$top_sql = "SELECT w.name, w.labor_id, COUNT(*) AS present_count
            FROM attendance a
            JOIN workers w ON a.worker_id = w.worker_id
            WHERE a.status = 'Present'
            GROUP BY a.worker_id
            ORDER BY present_count DESC
            LIMIT 1";
$top_result = $conn->query($top_sql);
$top_present = $top_result->fetch_assoc();

// Query for lowest present (excluding 0)
$low_sql = "SELECT w.name, w.labor_id, COUNT(*) AS present_count
            FROM attendance a
            JOIN workers w ON a.worker_id = w.worker_id
            WHERE a.status = 'Present'
            GROUP BY a.worker_id
            HAVING present_count > 0
            ORDER BY present_count ASC
            LIMIT 1";
$low_result = $conn->query($low_sql);
$low_present = $low_result->fetch_assoc();

$conn->close();
?>

<div style="max-width:600px; margin: 30px auto; text-align:center; font-size:18px; background:#fff; padding:20px; border-radius:10px; box-shadow:0 0 10px rgba(0,0,0,0.1);">
    <h3>🎖 Attendance Highlights</h3>
    <p>
        ✅ <strong>Highest Present:</strong><br>
        <?= htmlspecialchars($top_present['name']) ?> (ID: <?= htmlspecialchars($top_present['labor_id']) ?>)<br>
        Days Present: <strong><?= $top_present['present_count'] ?></strong>
    </p>
    <hr style="margin: 20px 0;">
    <p>
        🚨 <strong>Lowest Present:</strong><br>
        <?= htmlspecialchars($low_present['name']) ?> (ID: <?= htmlspecialchars($low_present['labor_id']) ?>)<br>
        Days Present: <strong><?= $low_present['present_count'] ?></strong>
    </p>
</div>
            <p></p>
        </div>
    </div>
    
   <?php
// chart.php

require 'connection.php';

// Get attendance status counts
$status_counts = ['Present' => 0, 'Late' => 0, 'Absent' => 0];
$count_sql = "SELECT status, COUNT(*) as total FROM attendance GROUP BY status";
$count_result = $conn->query($count_sql);
while ($row = $count_result->fetch_assoc()) {
    $status_counts[$row['status']] = $row['total'];
}
$conn->close();
?>
  <br><br> 
 <style>
        body {
            font-family: Arial, sans-serif;
            padding: 30px;
            
            background: #f4f4f4;
            text-align: center;
        }
        .chart-container {
            width: 1000px;
            margin: auto;
            background: #fff;
            padding: 22px;
            box-shadow: 0 0 4px rgba(0,0,0,0.1);
            border-radius: 8px;
        }
        h2 {
            margin-bottom: 20px;
        }
    </style>

    <div class="chart-container">
    <h2>Attendance Summary</h2>
    <canvas id="attendanceChart" width="50" height="30"></canvas>
</div>

<script>
const ctx = document.getElementById('attendanceChart').getContext('2d');
const attendanceChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Present', 'Late', 'Absent'],
        datasets: [{
            label: 'Number of Workers',
            data: [
                <?= $status_counts['Present'] ?>,
                <?= $status_counts['Late'] ?>,
                <?= $status_counts['Absent'] ?>
            ],
            backgroundColor: ['green', 'orange', 'red'],
            borderWidth: 1
        }]
    },
    options: {
        plugins: {
            legend: { display: false }
        },
        scales: {
            y: {
                beginAtZero: true,
                stepSize: 1,
                title: {
                    display: true,
                    text: 'Count'
                }
            }
        }
    }
});
</script>
<?php
echo "<br><div style='text-align:center; margin-top: 20px;'>
        <a href='daily_attendance_summary.php' 
           style='display: inline-block; 
                  background-color: #00796b; 
                  color: white; 
                  padding: 10px 20px; 
                  text-decoration: none; 
                  font-weight: bold; 
                  border-radius: 5px; 
                  transition: background 0.3s;'
           onmouseover=\"this.style.backgroundColor='#004d40'\"
           onmouseout=\"this.style.backgroundColor='#00796b'\">
           ➤ Go to Daily Attendance Summary
        </a>
      </div>";
?>
<br><br>
<footer style="
    background-color: #00130d;
    color: white;
    text-align: center;
    padding: 10px 0;
    font-family: 'Segoe UI', sans-serif;
    font-size: 14px;
    border-top: 2px solid #d9e3dc;">
    © 2025 Smart Poultry Farm. All rights reserved.
</footer>

</body>
