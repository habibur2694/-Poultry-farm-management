<?php
// connection.php should define $conn (MySQLi connection to 'farm' DB)
require_once 'connection.php';

$query = "SELECT product_name, market_location, current_price, regional_avg FROM market_prices";
$result = $conn->query($query);

$labels = [];
$current_prices = [];
$regional_avgs = [];

while ($row = $result->fetch_assoc()) {
    $labels[] = $row['product_name'] . " – " . $row['market_location'];
    $current_prices[] = floatval($row['current_price']);
    $regional_avgs[] = floatval($row['regional_avg']);
}
?>


    <title>Regional Price Comparison</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: sans-serif;
            background: #f2fef6;
            padding: 30px;
        }
        .chart-container {
            width: 90%;
            max-width: 900px;
            margin: auto;
            background: #ffffff;
            padding: 20px 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #26734d;
            margin-bottom: 25px;
        }
    </style>


<div class="chart-container">
    <h2>📊 Regional Price Comparison (by Location)</h2>
    <canvas id="priceChart"></canvas>
</div>

<script>
const ctx = document.getElementById('priceChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [
            {
                label: 'Current Price',
                data: <?= json_encode($current_prices) ?>,
                backgroundColor: 'rgba(39, 174, 96, 0.7)',
                borderColor: 'rgba(39, 174, 96, 1)',
                borderWidth: 1
            },
            {
                label: 'Regional Avg',
                data: <?= json_encode($regional_avgs) ?>,
                backgroundColor: 'rgba(149, 165, 166, 0.7)',
                borderColor: 'rgba(127, 140, 141, 1)',
                borderWidth: 1
            }
        ]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: false,
                title: {
                    display: true,
                    text: 'Price (USD)'
                }
            },
            x: {
                ticks: {
                    callback: function(value) {
                        // wrap long labels if needed
                        return value.length > 20 ? value.substring(0, 20) + "..." : value;
                    }
                }
            }
        },
        plugins: {
            tooltip: {
                callbacks: {
                    title: function(context) {
                        return context[0].label;
                    }
                }
            }
        }
    }
});
</script>

